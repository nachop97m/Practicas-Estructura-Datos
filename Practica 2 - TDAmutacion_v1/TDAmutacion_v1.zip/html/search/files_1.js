var searchData=
[
  ['enfermedad_2eh',['enfermedad.h',['../enfermedad_8h.html',1,'']]],
  ['enfermedad_2ehxx',['enfermedad.hxx',['../enfermedad_8hxx.html',1,'']]]
];

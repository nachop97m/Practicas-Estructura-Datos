var searchData=
[
  ['load',['load',['../principal_8cpp.html#aff87f713d8949bae17b25aade0c820bc',1,'principal.cpp']]]
];

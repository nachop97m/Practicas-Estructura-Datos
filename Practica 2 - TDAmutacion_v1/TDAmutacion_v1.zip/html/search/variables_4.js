var searchData=
[
  ['id',['ID',['../classenfermedad.html#a689cdbd469ecc28e045bda2f62a229d2',1,'enfermedad::ID()'],['../classmutacion.html#aafc39218473e0f21eb0c3dc05dd4f35e',1,'mutacion::ID()']]]
];

var searchData=
[
  ['name',['name',['../classenfermedad.html#ad7c4204057028a73bde6022678c6813e',1,'enfermedad']]]
];

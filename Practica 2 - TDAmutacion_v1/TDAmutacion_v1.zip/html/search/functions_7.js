var searchData=
[
  ['setcaf',['setCaf',['../classmutacion.html#a447b9009932a64b2ed6269ed2577f865',1,'mutacion']]],
  ['setchr',['setChr',['../classmutacion.html#a147ee1f35c78ab0b7cf891067bf2e336',1,'mutacion']]],
  ['setclnsig',['setClnsig',['../classmutacion.html#aed8c1aedd3468bf27bafab931d576454',1,'mutacion']]],
  ['setcommon',['setCommon',['../classmutacion.html#ab62d36e9bad78d43ace74fdaec909ca6',1,'mutacion']]],
  ['setdatabase',['setDatabase',['../classenfermedad.html#ac1f009307d52232420a72264e9c2ce3f',1,'enfermedad']]],
  ['setenfermedades',['setEnfermedades',['../classmutacion.html#a74da1d35cb0947b597ddf3b33e270d23',1,'mutacion']]],
  ['setgenes',['setGenes',['../classmutacion.html#a0cd370211bab4ae95120a68c57a92bed',1,'mutacion']]],
  ['setid',['setID',['../classenfermedad.html#a5ad52bdce8de9ac4fe25b460dc699af4',1,'enfermedad::setID()'],['../classmutacion.html#af6288453d3cb4e29b8be304ca262b170',1,'mutacion::setID()']]],
  ['setname',['setName',['../classenfermedad.html#a18f621d13de01c0b06a05757ddd8a087',1,'enfermedad']]],
  ['setpos',['setPos',['../classmutacion.html#a2667189a28d3ac983a8f63ca92e81fba',1,'mutacion']]],
  ['setref_5falt',['setRef_alt',['../classmutacion.html#af90752d5ce0e83943ea891ce995989f1',1,'mutacion']]]
];

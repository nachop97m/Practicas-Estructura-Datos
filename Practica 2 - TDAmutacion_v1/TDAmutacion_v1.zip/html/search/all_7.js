var searchData=
[
  ['name',['name',['../classenfermedad.html#ad7c4204057028a73bde6022678c6813e',1,'enfermedad']]],
  ['namecontains',['nameContains',['../classenfermedad.html#a31f2b1bed5745d9f00f3e567c04e68af',1,'enfermedad']]]
];

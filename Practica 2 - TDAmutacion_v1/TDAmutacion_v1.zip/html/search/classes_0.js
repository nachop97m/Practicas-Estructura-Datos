var searchData=
[
  ['enfermedad',['enfermedad',['../classenfermedad.html',1,'']]]
];

var searchData=
[
  ['cuentamutacionesenfermedad',['cuentaMutacionesEnfermedad',['../principal_8cpp.html#a61f9d7c309afbf7234d83ddf441c2ac9',1,'principal.cpp']]]
];

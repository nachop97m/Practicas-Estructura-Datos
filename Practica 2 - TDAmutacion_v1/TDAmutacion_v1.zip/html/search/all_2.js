var searchData=
[
  ['enfermedad',['enfermedad',['../classenfermedad.html',1,'enfermedad'],['../classenfermedad.html#a60eb5e620b0bf9a53d4f0980031aeefd',1,'enfermedad::enfermedad()'],['../classenfermedad.html#a7caef55b00a31ce18191ceaba81ed20c',1,'enfermedad::enfermedad(const string &amp;name, const string &amp;ID, const string &amp;database)']]],
  ['enfermedad_2eh',['enfermedad.h',['../enfermedad_8h.html',1,'']]],
  ['enfermedad_2ehxx',['enfermedad.hxx',['../enfermedad_8hxx.html',1,'']]],
  ['enfermedades',['enfermedades',['../classmutacion.html#ac8cca92dea1ab6fb9c193eed55a5ad28',1,'mutacion']]]
];

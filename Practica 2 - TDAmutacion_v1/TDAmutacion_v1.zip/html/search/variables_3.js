var searchData=
[
  ['genes',['genes',['../classmutacion.html#af0048945b6062d6eb88b91db707993f6',1,'mutacion']]]
];

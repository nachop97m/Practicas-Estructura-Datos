var searchData=
[
  ['enfermedades',['enfermedades',['../classmutacion.html#ac8cca92dea1ab6fb9c193eed55a5ad28',1,'mutacion']]]
];

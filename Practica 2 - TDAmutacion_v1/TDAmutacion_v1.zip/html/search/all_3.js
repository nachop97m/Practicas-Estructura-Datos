var searchData=
[
  ['genes',['genes',['../classmutacion.html#af0048945b6062d6eb88b91db707993f6',1,'mutacion']]],
  ['getcaf',['getCaf',['../classmutacion.html#a1eb523be88f47d1f4ef8324ca7016174',1,'mutacion']]],
  ['getchr',['getChr',['../classmutacion.html#aefb0a9a6a8278f0d192ebc044198399c',1,'mutacion']]],
  ['getclnsig',['getClnsig',['../classmutacion.html#aa59e921d4a64cf1be5cd4d99076234ee',1,'mutacion']]],
  ['getcommon',['getCommon',['../classmutacion.html#abc353016535a561fbd8e902c83861228',1,'mutacion']]],
  ['getdatabase',['getDatabase',['../classenfermedad.html#a79d304a2e39ea391917744fd4d8f168d',1,'enfermedad']]],
  ['getenfermedades',['getEnfermedades',['../classmutacion.html#aacfdae8cf04968fdc8fa803c8e5adb81',1,'mutacion']]],
  ['getgenes',['getGenes',['../classmutacion.html#a62462017a747cc19bf33abc3d5b69a8c',1,'mutacion']]],
  ['getid',['getID',['../classenfermedad.html#aaf9b9135b1d4efda7dc61856fce1b7b2',1,'enfermedad::getID()'],['../classmutacion.html#a6e3fa261f38b413aff9172fe065da8b8',1,'mutacion::getID()']]],
  ['getname',['getName',['../classenfermedad.html#ab22f6f0140a5fe5a331d72920d95f55b',1,'enfermedad']]],
  ['getpos',['getPos',['../classmutacion.html#ad08cb3c30da4195adc3c22d0b4c8edd7',1,'mutacion']]],
  ['getref_5falt',['getRef_alt',['../classmutacion.html#a241c1c54950209830ea7762ce8d7da58',1,'mutacion']]]
];

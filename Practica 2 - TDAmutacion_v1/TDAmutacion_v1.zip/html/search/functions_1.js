var searchData=
[
  ['enfermedad',['enfermedad',['../classenfermedad.html#a60eb5e620b0bf9a53d4f0980031aeefd',1,'enfermedad::enfermedad()'],['../classenfermedad.html#a7caef55b00a31ce18191ceaba81ed20c',1,'enfermedad::enfermedad(const string &amp;name, const string &amp;ID, const string &amp;database)']]]
];

var searchData=
[
  ['ktree_3c_20t_2c_20k_20_3e',['ktree&lt; T, K &gt;',['../classktree_1_1node.html#a2acf8e09c28d989cf6a77f0437e32e39',1,'ktree::node']]]
];

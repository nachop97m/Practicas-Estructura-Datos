var searchData=
[
  ['node',['node',['../classktree_1_1node_1_1child__iterator.html#a3700a7180235e9a28534b15d5922de12',1,'ktree::node::child_iterator']]]
];

var searchData=
[
  ['parent',['parent',['../classktree_1_1node.html#ac985d04cae9a8b6a5137aff15f742e3a',1,'ktree::node::parent()'],['../classktree_1_1const__node.html#a0ead125a85ccf4ddecb46bea325fad68',1,'ktree::const_node::parent()']]],
  ['prune_5fk_5fchild',['prune_k_child',['../classktree.html#ae10914de8d5fc7d594bc0f4364e255c1',1,'ktree']]]
];

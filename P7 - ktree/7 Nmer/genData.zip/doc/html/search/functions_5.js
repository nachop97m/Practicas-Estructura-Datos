var searchData=
[
  ['insert_5fk_5fchild',['insert_k_child',['../classktree.html#a10b652a0d5ad225d550726b5bed22a5c',1,'ktree::insert_k_child(ktree&lt; T, K &gt;::node &amp;n, int k, const T &amp;e)'],['../classktree.html#a33d22bb9a3960d93de58a6d84956bd13',1,'ktree::insert_k_child(node n, int k, ktree&lt; T, K &gt; &amp;rama)']]],
  ['insertar_5fvalorabb',['insertar_valorABB',['../ejemploKtree_8cpp.html#a6fd0b8ba76207351d65a115b86b84c62',1,'ejemploKtree.cpp']]]
];
